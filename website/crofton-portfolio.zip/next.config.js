module.exports = {
  reactStrictMode: true,
  output: 'export',
};