export default function Home() {
  return (
    <main className="p-10 text-center">
      <h1 className="text-4xl font-bold">William Brady</h1>
      <p className="text-lg mt-4 text-gray-600">Principal Cloud Security Architect</p>
      <p className="mt-2">Welcome to my portfolio at crofton.cloud</p>
    </main>
  );
}